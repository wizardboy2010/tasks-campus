# -*- coding: utf-8 -*-

import pandas as pd
import numpy as np

data = pd.ExcelFile('STOCKS.xlsx').parse()

