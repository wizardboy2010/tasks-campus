Requirements are NLTK, Sklearn libraries
One Can run .ipynb using Jupyter notebook