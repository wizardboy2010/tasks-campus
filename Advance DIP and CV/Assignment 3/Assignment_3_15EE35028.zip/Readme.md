# Talluri Surya Teja
I have used Python 3.7 for this Assignment

I have done 3 parts of problem for an image of path 'picasso/Self_Picasso.jpg'

to run the file just run 'python Assignment_3_15EE35028.py'